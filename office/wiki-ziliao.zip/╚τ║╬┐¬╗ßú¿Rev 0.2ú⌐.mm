
<map>
  <node ID="root" TEXT="如何开会（Rev 0.2）">
    <node TEXT="通识（如何开好会）" ID="2942147d9a8aabc2ff2000463d4bba1b" STYLE="bubble" POSITION="right">
      <node TEXT="高效会议的基本原则" ID="e6ec6cb46f28e0078562544bc821948b" STYLE="fork">
        <node TEXT="会议的类型" ID="9a0be6e6af54e18501d9b020fe3d1f4a" STYLE="fork">
          <node TEXT="脑暴会：少数人参加，只记录少讨论" ID="cb4047765877cbd5733bec21310b1c59" STYLE="fork"/>
          <node TEXT="评审会：一人讲，多人听，少讨论，有结论" ID="0a9e9db7c28eb9a580ef6379f9af144b" STYLE="fork"/>
          <node TEXT="信息互通会(如周会)：只讲尽量不讨论" ID="0d4051547dff88df082dcb26ec6faacb" STYLE="fork"/>
          <node TEXT="讨论会：少数人参加，互通信息，尝试达成共识" ID="c36a443ba13a77a14356c634032bfbb7" STYLE="fork"/>
          <node TEXT="决策会：一人讲整理好的报告，老板决策，多人旁听" ID="c3816c233feb9189c512aa7835931d0f" STYLE="fork"/>
        </node>
        <node TEXT="有准备：少数人线下梳理，通常会上出现无预案的问题则表示失败" ID="99414b4254c516fe42d3b6e001627dff" STYLE="fork"/>
        <node TEXT="收敛：多数人不讨论，任何问题不能在一分钟内达成一致则转线下" ID="eaf6654ec1e23406d5af814e31d774fc" STYLE="fork"/>
        <node TEXT="专注：目标清晰，议程不发散，与会者会上不开小会" ID="116480b35ad0d8a20bdb02e98401685d" STYLE="fork"/>
        <node TEXT="明确：会议要明确要解决问题" ID="6e2f802cc327142f2ee888dfef8e09ec" STYLE="fork"/>
        <node TEXT="责任到人：会议结论责任(TODO)到人" ID="6c3f65985172a93498b5c5b53beb37b8" STYLE="fork"/>
      </node>
      <node TEXT="前提" ID="57b3ccabad85a02eedd83347693a3f35" STYLE="fork">
        <node TEXT="有经验的会议主持人" ID="60fb3d5729f6237d8d0df8088afa553b" STYLE="fork"/>
        <node TEXT="有明确的目标" ID="04ad96f68d4955a8c933ea4e756cf175" STYLE="fork"/>
        <node TEXT="正确的人出席" ID="3135a5a87505c5c8feada3a1fa20e135" STYLE="fork">
          <node TEXT="了解上下文的人" ID="973a0da6f6eaa0a504d623dbc7bc8f99" STYLE="fork"/>
          <node TEXT="能够做决策的人" ID="eb4d0c4185802f4feae7b8c9aee50961" STYLE="fork"/>
          <node TEXT="与会者知道自己为什么参会、必须做什么回应" ID="6bde5d60cdbde85d2653a927bc4a2be6" STYLE="fork"/>
        </node>
      </node>
      <node TEXT="会前" ID="92da5051f3e804da400b69b4f9c0f41b" STYLE="fork">
        <node TEXT="提前一天时间飞书发会议邀请" ID="1ff849ed77ad71e39d33048e0caac103" STYLE="fork">
          <node TEXT="无法满足的紧急会议提前半天" ID="19c5ad2a444bf567f104d0b2dc2c88e3" STYLE="fork"/>
        </node>
        <node TEXT="建立飞书会议群（如已存在，可沿用）" ID="616c7d5c6ddab450e161ea54f85641b2" STYLE="fork"/>
        <node TEXT="会邀发出后立即发出会议文档" ID="1c396b0171d00e5535272b9d8ecb0349" STYLE="fork">
          <node TEXT="说明项目的目标及本次会议的目标" ID="7b6da2aa4190f39360dc8473153b9063" STYLE="fork"/>
          <node TEXT="会议所对应项目相关资料" ID="7669c82169c704d6dd029327ad75a983" STYLE="fork"/>
          <node TEXT="声明必须参会人员" ID="51ad5e098509786fdfad5219401d0313" STYLE="fork"/>
          <node TEXT="参会人员清楚会议中所必须做出的回应" ID="d439527f134db1a27a75c8c414075b16" STYLE="fork"/>
          <node TEXT="紧急会议要求显著告知必须人员阅读文档并给予阅读时间" ID="da5d5be70544d5ccf93046bbb153ace4" STYLE="fork"/>
        </node>
        <node TEXT="会议文档发出后，群里单圈必须参会的人员，提醒他们必须阅读文档、准时参会" ID="587136887534ea71a0a46e1376a441cc" STYLE="fork"/>
      </node>
      <node TEXT="会中" ID="a3b92fc8ae6ef5a55f076ff470977933" STYLE="fork">
        <node TEXT="准时开始，尽早开远程方便异地同学尽早加入" ID="bf50746e6615fac81d2889f4eb6d5d0b" STYLE="fork"/>
        <node TEXT="点名，确保必须参会人员均已到会" ID="42e0392125be51fe3aa5e93b875750df" STYLE="fork"/>
        <node TEXT="开场宣讲会议目标及议程" ID="eff15583eb04829a391ad78c16ec4277" STYLE="fork"/>
        <node TEXT="如发现会议涉及的关键人员未通知，会议解散重开，不得中途加人" ID="50ef433e642344575bfb7b0503ff00d2" STYLE="fork"/>
        <node TEXT="依据议程控制节奏，以一小时为目标控制，避免超时" ID="90dcc1697592209e2947ca9b1ac88846" STYLE="fork"/>
        <node TEXT="会议应当形成结论，并有TODO，每个TODO要有owner" ID="8bcfd2fa67e5031770adfc534cbc81bf" STYLE="fork"/>
      </node>
      <node TEXT="会后" ID="7608740a9b061f161df7e9ab1a12f995" STYLE="fork">
        <node TEXT="主持人应在会议结束后30分钟内将结论和TODO同步到会议群，并跟踪后续执行情况" ID="686b0afcc67d002207acc7a1fc24c60d" STYLE="fork"/>
        <node TEXT="必须产出会议纪要" ID="4c3c3e7b7dec7cb90cb29998f7ac1cdc" STYLE="fork"/>
        <node TEXT="TODO的owner需要持续跟进内容，直至完成" ID="a9d2df25d282be13ff15160a76a678e0" STYLE="fork"/>
      </node>
    </node>
    <node TEXT="需求评审会" ID="f39f79d093679dae280daddeba779d9d" STYLE="bubble" POSITION="right">
      <node TEXT="主持人" ID="bd57876aeaad4a2212e785ab859b223b" STYLE="fork">
        <node TEXT="产品经理" ID="aba10ee471461acaae29505ab75d5f9f" STYLE="fork"/>
      </node>
      <node TEXT="会议目的" ID="9332320f1bb64e3c36f2486cb52ce7cb" STYLE="fork">
        <node TEXT="宣讲项目意义，传达产品理念" ID="6d3ee649e2f46f1096e773360274efc2" STYLE="fork"/>
        <node TEXT="完善需求，但不是头脑风暴，不要在会上讨论" ID="af0e28c81f19791055bb8b63f3c0f60f" STYLE="fork"/>
        <node TEXT="达成共识，建立成员责任感" ID="7b3843bd6dc45c9748fe115c71c3b1a8" STYLE="fork"/>
      </node>
      <node TEXT="会议目标" ID="ecd1d1f2f7f3cd20b915cc0701670b23" STYLE="fork">
        <node TEXT="团队达成共识，对执行该项目无异议" ID="38c8f6d06d021e8f437d7f7ecfc534f1" STYLE="fork"/>
        <node TEXT="对需求无异议，各模块负责人对所负责的模块如何执行无问题" ID="7d14cc4bf0e258c6fdb3fc589702ad84" STYLE="fork"/>
      </node>
      <node TEXT="会议议程" ID="93492f756eec3c918842bebeabb9605d" STYLE="fork">
        <node TEXT="不确定邀约人员的，会前与PMO团队确认" ID="849553e4d6a1a08bc7a4f510671b3cff" STYLE="fork"/>
        <node TEXT="无需逐模块念文档、逐模块确认即可" ID="9829cdb33b0710534b1c5b4364d7b910" STYLE="fork"/>
        <node TEXT="每模块需求方、前端、服务端、中台、测试均无疑问即可进入下一模块，任意一个环节有疑问方进行详细确认（而非讨论）" ID="d8170ff2b26660230e1a81444d8b4561" STYLE="fork"/>
        <node TEXT="已通知必须参加的团队缺勤的，视为无异议；若事后有问题，产品经理/DPM/PMO均可直接反馈向上级反馈" ID="bb0793cc4263f5eaf29d1fd5992fd0b1" STYLE="fork"/>
        <node TEXT="在确认中，如发现某环节考虑缺失，需参会人员之外的人员支持的，由PMO解散会议，沟通清楚后再开" ID="842f0108892143b85dbcb5820e398c01" STYLE="fork"/>
        <node TEXT="出现细节不清，需要讨论的，原则上每模块讨论不得超过2分钟；超过由PMO解散会议或者产品经理记为会议待办线下沟通" ID="3d88be4fc864ab6c446f6de51b8b04eb" STYLE="fork"/>
      </node>
      <node TEXT="会议结论" ID="5eea573fd734d0a54a74f17a54f85382" STYLE="fork">
        <node TEXT="确认是否还需重新召开需求评审会" ID="d6f504303a2ac1d9641e834d38ae8fc1" STYLE="fork"/>
        <node TEXT="明确待办事项及负责人、时限" ID="dd71f2f5a46ad0057e1bb493d8e4b9df" STYLE="fork"/>
        <node TEXT="如无需再次召开需求评审会，确认DPM及技术评审时间(可以待办形式留下)" ID="59d6a5cce3c7df4eb247852eee5b539a" STYLE="fork"/>
      </node>
    </node>
    <node TEXT="技术评审会" ID="8dd2c1876cb140f8b66237f5dd631a39" STYLE="bubble" POSITION="right">
      <node TEXT="主持人" ID="d20133c658e3fbfaf7a0786991a43b7d" STYLE="fork">
        <node TEXT="DPM" ID="862832ee171f9c0caf847dc26ffa3d87" STYLE="fork"/>
      </node>
      <node TEXT="会议目的" ID="d519f9704f63d218e627a3f0d0d3e151" STYLE="fork">
        <node TEXT="确认各团队对项目的理解一致及整体实现方案" ID="cec788041bdff855e328ad7acab3bf37" STYLE="fork"/>
        <node TEXT="从业务模块、功能入手逐一确认各团队实现方法能够环环相扣并能满足需求" ID="afc9dd09d3e047083c660cef335c6436" STYLE="fork"/>
        <node TEXT="确认方案能满足项目性能、兼容性等指标" ID="ac4d6afb7bcc5112c422439e7120c363" STYLE="fork"/>
        <node TEXT="确认方案的影响范围，以便测试团队编写测试用例" ID="cf98b8b47ffb2b741d529d87ddd7f828" STYLE="fork"/>
        <node TEXT="过架构师团队，确保技术架构统一" ID="af0cc3f774414be0ed9c139e7211eb6e" STYLE="fork"/>
        <node TEXT="确定排期" ID="7d674ae1f839f16c4375bfb7be236f63" STYLE="fork">
          <node TEXT="如大型项目无法现场给出排期，则已待办形式确定排期时间" ID="d706646c0f30bdacb2bea9537add0642" STYLE="fork"/>
        </node>
      </node>
      <node TEXT="会议目标" ID="3a684b7cf53f58eb02ab947dbbe64e3a" STYLE="fork">
        <node TEXT="达成技术方案及分工共识、给出排期" ID="33ab47fd77ce02b8c8cb7f76134bc6fb" STYLE="fork"/>
      </node>
      <node TEXT="会议议程" ID="08705c3b38518224d0f37507edd586a1" STYLE="fork">
        <node TEXT="会议只解决难点、澄清边界、确认方案" ID="08e8aa82894a193b70b855a0757621c6" STYLE="fork"/>
        <node TEXT="不在会上制定方案，只能选择方案" ID="17776fe7052452ae4d944ba946398a9f" STYLE="fork"/>
        <node TEXT="中途不加人，遇到环节缺失由DPM记为TODO待办解散后期重开" ID="5a976dc509e878be197d3a3adc6b7f4d" STYLE="fork"/>
        <node TEXT="技术文档原则上不要分团队写" ID="7a9860a0ba9859dc1e9fddb70ea880b6" STYLE="fork"/>
        <node TEXT="按功能模块确认，而不要分团队确认" ID="6a367278eb5d1a28d7ef6d70d9e628b8" STYLE="fork"/>
        <node TEXT="无需逐模块念文档、逐模块确认即可" ID="f53fae9ea82ab0fcec486a00acc888af" STYLE="fork"/>
        <node TEXT="针对每模块前端每功能，由前端、服务端、中台、测试等各环节确认，均无疑问即可进入下一模块，任意一个环节有疑问必须进行详细讨论" ID="baa9bf197c4ebf3a017d13eab8183b1c" STYLE="fork"/>
      </node>
      <node TEXT="会议结论" ID="f0682fb786ab7f3cc7d38c0091dcae6c" STYLE="fork">
        <node TEXT="确认是否还需重新召开技术评审会" ID="2960abbc9949e9046a1ec9a1510ac8b8" STYLE="fork"/>
        <node TEXT="确认排期及里程碑" ID="c310fdcbac2489233dbc85fcd3096e2e" STYLE="fork"/>
        <node TEXT="同步项目管理制度" ID="9ca61434e9d8cf3f1dc16ed4d426f38e" STYLE="fork"/>
      </node>
    </node>
  </node>
</map>